
// Create Dino Constructor

function Dino(species, weight, height, diet, where, when, fact){
    this.species = species;
    this.weight = weight;
    this.height = height;
    this.diet = diet;
    this.where = where;
    this.when = when;
    this.fact = fact;
    this.image = `images/${species}.png`;
}

const dinoJson = [
    {
        "species": "Triceratops",
        "weight": 13000,
        "height": 114,
        "diet": "herbavor",
        "where": "North America",
        "when": "Late Cretaceous",
        "fact": "First discovered in 1889 by Othniel Charles Marsh"
    },
    {
        "species": "Tyrannosaurus Rex",
        "weight": 11905,
        "height": 144,
        "diet": "carnivor",
        "where": "North America",
        "when": "Late Cretaceous",
        "fact": "The largest known skull measures in at 5 feet long."
    },
    {
        "species": "Anklyosaurus",
        "weight": 10500,
        "height": 55,
        "diet": "herbavor",
        "where": "North America",
        "when": "Late Cretaceous",
        "fact": "Anklyosaurus survived for approximately 135 million years."
    },
    {
        "species": "Brachiosaurus",
        "weight": 70000,
        "height": "372",
        "diet": "herbavor",
        "where": "North America",
        "when": "Late Jurasic",
        "fact": "An asteroid was named 9954 Brachiosaurus in 1991."
    },
    {
        "species": "Stegosaurus",
        "weight": 11600,
        "height": 79,
        "diet": "herbavor",
        "where": "North America, Europe, Asia",
        "when": "Late Jurasic to Early Cretaceous",
        "fact": "The Stegosaurus had between 17 and 22 seperate places and flat spines."
    },
    {
        "species": "Elasmosaurus",
        "weight": 16000,
        "height": 59,
        "diet": "carnivor",
        "where": "North America",
        "when": "Late Cretaceous",
        "fact": "Elasmosaurus was a marine reptile first discovered in Kansas."
    },
    {
        "species": "Pteranodon",
        "weight": 44,
        "height": 20,
        "diet": "carnivor",
        "where": "North America",
        "when": "Late Cretaceous",
        "fact": "Actually a flying reptile, the Pteranodon is not a dinosaur."
    },
    {
        "species": "Pigeon",
        "weight": 0.5,
        "height": 9,
        "diet": "herbavor",
        "where": "World Wide",
        "when": "Holocene",
        "fact": "All birds are living dinosaurs."
    }
]

// Create Dino Objects

const dinoObjects = dinoJson.map(dino =>
    new Dino(
        dino.species,
        dino.weight,
        dino.height,
        dino.diet,
        dino.where,
        dino.when,
        dino.fact
    )
)


//Getting Human Data from form-container

let comp = document.querySelector("#btn");
const form = document.getElementById('dino-compare');
comp.addEventListener('click', () => {
    let name = document.getElementById("name").value;
    let height = parseInt(document.getElementById("feet").value * 12) + parseInt(document.getElementById("inches").value);
    let weight = document.getElementById("weight").value;
    let diet = document.getElementById("diet").value;
    let image = "images/human.png";

    const human = {
        species: "human",
        name, 
        height, 
        weight, 
        diet,
        image
    }
    form.remove();
    dinoObjects.splice(4, 0, human)
    createGrid(human);
}); 


//Dinosaur Comparison- 1 based on Height
function heightComparison(dinosaur, human){                     
    if (dinosaur.height > human.height){
        return `The ${dinosaur.species} is ${dinosaur.height - human.height} inches taller when compared to you.`;
    }
    else if (dinosaur.height < human.height){
        return `You are ${human.height - dinosaur.height} inches taller than ${dinosaur.species}.`;
    }
    else{
        return `You and ${dinosaur.species} are of same height.`;
    }
}

//Dinosaur Comparison- 2 based on Weight
function weightComparison(dinosaur, human){
    if (dinosaur.weight > human.weight){
        return `The ${dinosaur.species} is ${dinosaur.weight - human.weight} heavier  when compared to you.`;
    }
    else if (dinosaur.weight < human.weight){
        return `You are ${dinosaur.weight - human.weight} heavier than ${dinosaur.species}`;
    }
    else{
        return `You and ${dinosaur.species} are of same weight.`
    }
}

//Dinosaur comparison- 3 based on Diet
function dietComparison(dinosaur, human){
    if(dinosaur.diet === human.diet){
        return `You both are ${dinosaur.diet}s`;
    }
    else{
        return `You are ${human.diet} and ${dinosaur.species} is ${dinosaur.diet}`;
    }
    
}
const facts = (index, dino, human) => {
    switch(index){
        case 1: {
            return heightComparison(dino, human);
            
        }
        case 2: {
            return weightComparison(dino, human);
            
        }
        case 3: {
            return dietComparison(dino, human);
            
        }
        case 4: {
            return dino.fact
            
        }
        case 5: {
            return dino.fact
            
        }
        case 6: {
            return dino.fact
            
        }
        case 7: {
            return dino.fact
            
        }
        case 8: {
            return dino.fact
            
        }
        default: return null
    }
}

const createGrid = (human) => {
    let grid = document.getElementById('grid');
    dinoObjects.forEach((dino) => {
        let div = document.createElement('div');
        let img = document.createElement('img');
        img.setAttribute('src', dino.image.toLowerCase())

        let heading = document.createElement('h3');
        let para = document.createElement('p');

        if(dino.species === 'Pigeon'){
            heading.innerText=dino.species
            para.innerText=dino.fact
        } else if(dino.species === 'human') {
            heading.innerText=dino.name
            para.innerText='Hooman'
        } else {
            heading.innerText=dino.species;
            let index = Math.floor((Math.random() * 7)+1)
            para.innerText=facts(index, dino, human)
        }
        grid.appendChild(div);
        div.classList.add('grid-item');
        div.appendChild(heading);
        div.appendChild(img);
        div.appendChild(para);
    });
}
