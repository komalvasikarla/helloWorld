/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
*/

/**
 * Define Global Variables
 * 
*/

const sections = document.querySelectorAll("section");
const navMenu = document.getElementById('navbar__list');

/**
 * End Global Variables
 * Start Helper Functions
 * 
*/

const generateATag = (name, id) => {

    const aTag = document.createElement('a');
    aTag.setAttribute('class', "menu__link");
    aTag.setAttribute('href', `#${id}`)
    aTag.setAttribute('ref', id)
    aTag.innerHTML += name;

    aTag.addEventListener('click', (e) => {
        e.preventDefault()
        generateSmoothScroll(id);
        setActiveClass(id);
    });
    return aTag;
}

// function generateBar(){

// }

/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav
const generateNavBar = () => { 

    sections.forEach(item => {
        const liTag = document.createElement('li');
        
        const sectionName = item.getAttribute('data-nav');
        const sectionId = item.getAttribute("id");

        const tag = generateATag(sectionName, sectionId);

        liTag.appendChild(tag);
        navMenu.appendChild(liTag);
    })
}

// Add class 'active' to section when near top of viewport
const setActiveClass = (id) => {
    const navLinks = document.querySelectorAll('.menu__link');
    for(let i=0; i < navLinks.length; i++){
        let linkRef = navLinks[i].getAttribute('ref')
        if(id === linkRef){
            sections[i].classList.add("your-active-class")
            navLinks[i].classList.add("your-active-class")  
        } else if(id != linkRef){
            sections[i].classList.remove("your-active-class")
            navLinks[i].classList.remove("your-active-class")
        }
    }
}

// Scroll to anchor ID using scrollTO event


/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 
generateNavBar();

// Scroll to section on link click
const generateSmoothScroll = (id) => {
    document.getElementById(id).scrollIntoView({behavior: "smooth"});
}

// Set sections as active
setActiveClass();