//dice1
var randomNumber1 = Math.floor(Math.random() * 6) + 1;
var randomDiceImg1 = "dice" + randomNumber1 + ".png";
var randomImage1 = "images/" + randomDiceImg1;

document.querySelector(".img1").setAttribute("src", randomImage1);


//dice2
var randomNumber2 = Math.floor(Math.random() * 6) + 1;
var randomDiceImg2 = "dice" + randomNumber2 + ".png";
var randomImage2 = "images/" + randomDiceImg2;

document.querySelector(".img2").setAttribute("src", randomImage2);


//Text generator
if (randomNumber1 < randomNumber2){
    document.querySelector("h1").innerHTML = "Player 2 wins"
}

else if (randomNumber1 > randomNumber2){
    document.querySelector("h1").innerHTML = "Player 1 wins"
}

else {
    document.querySelector("h1").innerHTML = "The match is draw"
}

