let gridHeight = document.querySelector('#inputHeight');
let gridWidth = document.querySelector('#inputWidth');
let gridCell = document.querySelector('#pixelCanvas');
let submitButton = document.querySelector('#sizePicker');
let tableCells = document.querySelectorAll('td');


//select color input
let color = document.querySelector('#colorPicker');

/**
 *@description creates a grid of squares by taking the values from the user
 *@param int gridHeight - number of squares representing the height of the grid.
 *@param int gridWidth - number of squares representing the width of the grid. 
 */




function makeGrid() {
	for (let heightValue = 0; heightValue < gridHeight.value; heightValue++) {
		let row = gridCell.insertRow();

		for (let widthValue = 0; widthValue < gridWidth.value; widthValue++) {
			let column = row.insertCell();
		}
	}
}

submitButton.addEventListener('submit', function(evt) {
	gridCell.innerHTML = "";
	evt.preventDefault(); // the preventDefault() method cancels the event if it is cancelable,meaning it will prevent the page from reloading on submitting the form.  
	makeGrid(gridHeight, gridWidth);


});


gridCell.addEventListener('click', function(evt) {
	evt.target.style.backgroundColor = color.value;
});
